from django.shortcuts import render, redirect
# Create your views here.

from store.models.product import Product
from store.models.customer import Customer
from django.views import View

class Cart(View):
	def get(self , request):
		ids = list(request.session.get('cart').keys())
		products = Product.get_products_by_id(ids)
		return render(request, 'cart.html', {'product' : products})

	